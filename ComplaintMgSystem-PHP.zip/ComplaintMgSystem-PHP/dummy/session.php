<?php
  session_start();
  error_reporting(0);
  $eng_session = $_SESSION['name'];
 ?>
